import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'SIBER & TECH DEV — Biro Teknologi',
  description: 'Join the frontline of digital defense. Biro Siber & Biro Pengembangan Teknologi — rekrutmen taruna pilihan.',
  keywords: 'cyber security, teknologi, biro siber, pengembangan teknologi, rekrutmen taruna',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="id">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&family=Exo+2:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=Share+Tech+Mono&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="antialiased">
        {children}
      </body>
    </html>
  )
}
